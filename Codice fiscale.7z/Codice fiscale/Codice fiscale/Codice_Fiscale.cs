﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Codice_fiscale
{
    class Codice_Fiscale
    {
        private string nome;
        private string cognome;
        string[] codes = { "A", "B", "C", "D", "E", "H", "L", "M", "P", "R", "S", "T" };
        //array per il controllo delle vocali
        char[] vocali = { 'A', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å',
                           'E', 'È', 'É', 'Ê', 'Ë',
                           'I', 'Ì', 'Í', 'Î', 'Ï',
                           'O', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö',
                           'U', 'Ù', 'Ú', 'Û', 'Ü'
        };
        private string yyyymmdd;
        private string sesso;
        private string comune;

        public Codice_Fiscale(string A, string B, string C, string S, string D)
        {
            nome = A;
            cognome = B;
            yyyymmdd = C;
            sesso = S;
            comune = D;
        }
        //metodo per rimuovere gli accenti!
        private string RemoveAccents(string text)
        {
            var stringaNormalizzata = text.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in stringaNormalizzata)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }


        public string Cognome()
        {
            string a = cognome.ToUpper();
            string s = "";
            if (cognome.Length < 3)
            {
                for (int i = 0; i < cognome.Length; i++)
                {
                    char s1 = a[i];
                    if (s1 == ' ') { }
                    else
                    {
                        s = s + RemoveAccents(s1.ToString());
                    }
                }
                s = s + "X";
            }
            else
            {
                for (int i = 0; i < cognome.Length; i++)
                {
                    char s1 = a[i];
                    if (s1 == ' ') { }
                    else
                    {
                        if (vocali.Any(s1.ToString().Contains)) { }     //controlla se all'interno dell'array 
                        else                                            //è presente il valore del char s1
                        {
                            s = s + s1;
                        }
                    }
                }
                if (s.Length < 3)
                {
                    for (int i = 0; s.Length < 3; i++)
                    {
                        char s1 = a[i];
                        if (s1 == ' ') { }
                        else
                        {
                            if (vocali.Any(s1.ToString().Contains))
                            {
                                ;
                                s = s + RemoveAccents(s1.ToString());
                            }
                        }
                    }
                }
            }
            return s.Substring(0, 3);
        }

        public string Nome()
        {
            string s = "";                          //soluzione
            string a = nome.ToUpper();              //porta il nome in maiuscolo 
            if (nome.Length < 3)
            {
                for (int i = 0; i < nome.Length; i++)
                {
                    char s1 = a[i];
                    if (s1 == ' ') { }
                    else
                    {
                        s = s + s1;
                    }
                }
                s = s + "X";
            }
            else
            {
                for (int i = 0; i < nome.Length; i++)
                {
                    char s1 = a[i];
                    if (s1 == ' ') { }
                    else
                    {
                        if (vocali.Any(s1.ToString().Contains))
                        {
                        }
                        else
                        {
                            s = s + s1;
                        }
                    }
                }
                if (s.Length < 3)
                {
                    for (int i = 0; i < nome.Length; i++)
                    {
                        char s1 = a[i];
                        if (s1 == ' ') { }
                        else
                        {
                            if (vocali.Any(s1.ToString().Contains))
                            {
                                s = s + RemoveAccents(s1.ToString());
                            }
                        }
                    }
                }
            }
            return s.Substring(0, 3);
        }

        //da qui in poi lavoro su anno, mese e data di nascita; mi appoggio a 3 sotto-metodi
        private string Year()
        {
            string year = yyyymmdd.Substring(2, 2);
            return year;
        }

        private string Month()
        {
            string month = yyyymmdd.Substring(4, 2);
            int mm = Convert.ToInt32(month) - 1;
            string a = codes[mm];                   //cerca la posizione dell'array
            return a;
        }

        private string Bday()
        {
            string date = yyyymmdd.Substring(6, 2);
            int dd = Convert.ToInt32(date);
            string day = "";
            if (sesso == "M")
                day = date;
            else if (sesso == "F")
            {
                day = (dd + 40).ToString();
            }
            return day;
        }

        public string DDN()
        {
            return Year() + Month() + Bday();
        }

        //metodo codice di controllo
        public string CodControllo(string codice)
        {
            codice = codice.ToUpper();
            string pari = "";
            string dispari = "";
            int valoreNumericoPari = 0;
            int valoreNumericoDispari = 0;
            //trovo le stringe pari e dspari
            bool flag = false;
            for (int i = 0; i < 13; i++)
            {
                char c = codice[i];
                if (flag == true)
                {
                    pari = pari + c;
                    flag = false;
                }
                else
                {
                    dispari = dispari + c;
                    flag = true;
                }
            }

            int[] CodValoriNumericiDispari = { 1, 0, 5, 7, 9, 13, 15, 17, 19, 21 };
            string[] CodLettereDispari = { "B", "A", "K", "P", "L", "C", "Q", "D", "R", "E", "V", "O", "S", "F", "T", "G", "U", "H", "M", "I", "N", "J", "W", "Z", "Y", "X" };
            string[] CodLetterePari = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            //trovo i valori pari
            for (int i = 0; i < pari.Length; i++)
            {
                string c = pari[i].ToString();
                int variabilePari = 0;
                bool convertibilePari = Int32.TryParse(Convert.ToString(c), out variabilePari);    //bool che capisce se il char è un numero (nella parte dei pari)

                if (convertibilePari == true)
                {
                    int a = Convert.ToInt32(c);
                    valoreNumericoPari = valoreNumericoPari + a;
                }
                else
                {
                    int a = Array.IndexOf(CodLetterePari, c);
                    valoreNumericoPari = valoreNumericoPari + a;
                }
            }
            //trovo i valori dispari
            for (int i = 0; i < dispari.Length; i++)
            {
                string c = dispari[i].ToString();
                int variabileDispari = 0;
                bool convertibileDispari = Int32.TryParse(Convert.ToString(c), out variabileDispari);    //bool che capisce se il char è un numero (nella parte dei dispari)

                if (convertibileDispari == true)
                {
                    int a = CodValoriNumericiDispari[variabileDispari];
                    valoreNumericoDispari = valoreNumericoDispari + a;
                }
                else
                {
                    int a = Array.IndexOf(CodLettereDispari, c);
                    valoreNumericoDispari = valoreNumericoDispari + a;
                }

            }


            //Ora si procede sommado i valori trovati
            int CodControlloNumerico = valoreNumericoDispari + valoreNumericoPari;
            int resto = (CodControlloNumerico % 26);
            string CodControlloFinale = CodLetterePari[resto];
            return CodControlloFinale;

        }
    }
}