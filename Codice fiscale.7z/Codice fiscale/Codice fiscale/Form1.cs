﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Codice_fiscale
{
    public partial class Form1 : Form
    {
        private Codice_Fiscale c;
        public Form1()
        {
            
            InitializeComponent();
            //Comuni
            StreamReader comuni = new StreamReader(@"..\Dati\comuni.txt");
            string riga = comuni.ReadLine();
            while (riga != null)
            {
                comboBoxComuni.Items.Add(riga);
                riga = comuni.ReadLine();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && comboBoxComuni.Text != "")
            {

                //creo le stringhe in input necessarie per la classe
                string Cognome = textBox1.Text;         //cognome
                string Nome = textBox2.Text;            //nome
                DateTime DDN = dateTimePicker1.Value;
                string Date = DDN.ToString("yyyyMMdd");      //data di nascita
                string Sesso = comboBoxComuni.Text;
                Sesso = Sesso[0].ToString();
                //luogo di nascita
                string Nascita = comboBoxComuni.Text;
                string Codice = "";         //la stringa "codice" rappresenta il valore numerico del comune
                bool flag = false;
                for (int i = 0; i < Nascita.Length; i++)
                {
                    char c = Nascita[i];
                    if (c == ')') { flag = false; }
                    if (!flag) { }
                    else
                    { Codice = Codice + c; }
                    if (c == '(') { flag = true; }
                    else { }
                }
                //inizializzo la classe!
                c = new Codice_Fiscale(Nome, Cognome, Date, Sesso, Codice);
                /* btnreset.Visible = false;
                 btnreset.Enabled = false;
                 label6.Visible = true;
                 label6.Enabled = true;
                 //BtnReset.Visible = true;
                 textBox1.Enabled = false;
                 textBox2.Enabled = false;
                 dateTimePicker1.Enabled = false;
                 comboBox1.Enabled = false;
                 */
                comboBoxComuni.Enabled = false;
                string codFiscaleIniziale = c.Cognome() + c.Nome() + c.DDN() + Codice;      //manca il codice di controllo
                string CodControllo = c.CodControllo(codFiscaleIniziale);
                label6.Text = codFiscaleIniziale + CodControllo;
               
            }
            else
            {

            }
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {

        }
    }
}

